const DAY_WORDS = /\b(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)(?:'s)?\b/i;
const FIB_WORDS = /\b(?:fib(?:onacci)?|38\.2%|50%|61\.8%)\b/i;
const BENCHMARK_VALIDATOR_VERSION = "1.15.0";

function finiteNumber(value) {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function normalizeDirection(value = "") {
  const text = String(value || "").toLowerCase();
  if (/bull|buy|long/.test(text)) return "bullish";
  if (/bear|sell|short/.test(text)) return "bearish";
  if (/range|neutral|sideways/.test(text)) return "range";
  return "unknown";
}

function normalizeText(value = "") {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9.]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function parseList(value) {
  if (Array.isArray(value)) return value.map(finiteNumber).filter((item) => item !== null);
  return String(value || "")
    .split(/[\s,;|]+/)
    .map(finiteNumber)
    .filter((item) => item !== null);
}

function parseTextList(value) {
  if (Array.isArray(value)) {
    return value.map((item) => String(item || "").trim()).filter(Boolean);
  }
  return String(value || "")
    .split(/[,;|]+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function normalizeAreaType(value = "") {
  const text = String(value || "")
    .toLowerCase()
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (!text) return "unknown";
  if (text.includes("converted support")) return "converted support";
  if (text.includes("converted resistance")) return "converted resistance";
  if (text.includes("demand")) return "demand";
  if (text.includes("supply")) return "supply";
  if (text.includes("support")) return "support";
  if (text.includes("resistance")) return "resistance";
  if (text === "buy area" || text === "sell area") return text;
  return text;
}

function areaTypeMatches(actualValue, expectedValue) {
  const actual = normalizeAreaType(actualValue);
  const expected = normalizeAreaType(expectedValue);
  if (expected === "unknown") return true;
  if (expected === "buy area") {
    return ["support", "demand", "converted support"].includes(actual);
  }
  if (expected === "sell area") {
    return ["resistance", "supply", "converted resistance"].includes(actual);
  }
  if (expected === "support") {
    return ["support", "converted support"].includes(actual);
  }
  if (expected === "resistance") {
    return ["resistance", "converted resistance"].includes(actual);
  }
  return actual === expected;
}

function isSupplyDemandType(value) {
  return ["supply", "demand"].includes(normalizeAreaType(value));
}

function normalizeZoneBounds(lowValue, highValue) {
  const low = finiteNumber(lowValue);
  const high = finiteNumber(highValue);
  if (low === null || high === null || low === high) return null;
  return { low: Math.min(low, high), high: Math.max(low, high) };
}

function expectedEntryZone(expectation = {}, entryNumber = 1) {
  const type = expectation[`expectedEntry${entryNumber}Type`];
  if (!isSupplyDemandType(type)) return null;
  return normalizeZoneBounds(
    expectation[`expectedEntry${entryNumber}ZoneLow`],
    expectation[`expectedEntry${entryNumber}ZoneHigh`]
  );
}

function areaBounds(area) {
  if (!area) return null;
  const center = finiteNumber(area.center);
  const low = finiteNumber(area.zoneLow) ?? center;
  const high = finiteNumber(area.zoneHigh) ?? center;
  if (low === null || high === null) return null;
  return { low: Math.min(low, high), high: Math.max(low, high), center };
}

function priceInsideZone(price, zone, tolerance = 0) {
  const value = finiteNumber(price);
  if (value === null || !zone) return false;
  return value >= zone.low - tolerance && value <= zone.high + tolerance;
}

function areaMatchesExpectedZone(area, expectedZone, tolerance = 0) {
  const actual = areaBounds(area);
  if (!actual || !expectedZone) return false;

  // A selected entry anchor inside the expected S/D area is sufficient. This
  // covers customer-facing output that exposes one actionable price while the
  // structured facts retain the full candle-defined zone.
  if (priceInsideZone(actual.center, expectedZone, tolerance)) return true;

  const overlapLow = Math.max(actual.low, expectedZone.low);
  const overlapHigh = Math.min(actual.high, expectedZone.high);
  const overlap = Math.max(0, overlapHigh - overlapLow + tolerance * 2);
  const actualWidth = Math.max(0, actual.high - actual.low);
  const expectedWidth = Math.max(0, expectedZone.high - expectedZone.low);
  const narrowerWidth = Math.min(actualWidth, expectedWidth);

  // For two genuine areas, require meaningful overlap rather than accepting a
  // broad zone that merely brushes the benchmark boundary. Point-like actual
  // output is handled by the anchor-containment rule above.
  return narrowerWidth > 0 && overlap / narrowerWidth >= 0.25;
}

function textMentionsZone(text, zone, tolerance = 0) {
  if (!zone) return false;
  const candidates = String(text || "").match(/\d+(?:\.\d+)?/g) || [];
  return candidates.some((candidate) =>
    priceInsideZone(Number(candidate), zone, tolerance)
  );
}

function formatExpectedZone(zone) {
  return zone ? `${zone.low}–${zone.high}` : "";
}

function feedbackMentionsTerm(text, term) {
  const normalizedText = normalizeText(text);
  const normalizedTerm = normalizeText(term);
  return Boolean(normalizedTerm) && normalizedText.includes(normalizedTerm);
}

function parsePriceExpectations(value) {
  const tokens = Array.isArray(value)
    ? value.map((item) => String(item))
    : String(value || "").split(/[\s,;|]+/);

  return tokens
    .map((raw) => {
      const text = String(raw || "").trim();
      const value = finiteNumber(text);
      if (value === null) return null;
      const decimalText = text.includes(".") ? text.split(".")[1] : "";
      return {
        value,
        text,
        digits: Math.max(0, Math.min(decimalText.length, 8)),
      };
    })
    .filter(Boolean);
}

function priceDigits(price) {
  const text = String(price);
  const decimals = text.includes(".") ? text.split(".")[1].length : 0;
  return Math.max(0, Math.min(decimals, 8));
}

function defaultTolerance(price) {
  const n = Math.abs(Number(price));
  if (n >= 1000) return 1.5;
  if (n >= 100) return 0.15;
  if (n >= 10) return 0.03;
  if (n >= 1) return 0.00025;
  return 0.00008;
}

function exactLevelTolerance(price, expectedDigits = null) {
  const digits = Number.isInteger(expectedDigits)
    ? expectedDigits
    : priceDigits(price);
  return Math.max(Number.EPSILON * 100, 0.5 * 10 ** -digits);
}

function entryFrom(value, index = 0) {
  if (!value || typeof value !== "object") return null;
  const zoneLow = finiteNumber(value.zoneLow);
  const zoneHigh = finiteNumber(value.zoneHigh);
  const center =
    finiteNumber(value.authoritativeCenter) ??
    finiteNumber(value.center) ??
    finiteNumber(value.price) ??
    (zoneLow !== null && zoneHigh !== null ? (zoneLow + zoneHigh) / 2 : null);

  if (center === null && zoneLow === null && zoneHigh === null) return null;
  return {
    order: Number(value.executionOrder || value.rank || index + 1),
    center,
    zoneLow: zoneLow ?? center,
    zoneHigh: zoneHigh ?? center,
    areaType: String(value.areaType || value.type || ""),
    levelText: String(value.levelText || value.zoneText || ""),
  };
}

function factsSelectedEntries(result = {}) {
  return Array.isArray(result?.analysisFacts?.selectedEntryAreas)
    ? result.analysisFacts.selectedEntryAreas.map(entryFrom).filter(Boolean)
    : [];
}

function canonicalSelectedEntries(result = {}) {
  const lockedEntries = Array.isArray(result?.finalFeedback?.narrativeLock?.selectedEntries)
    ? result.finalFeedback.narrativeLock.selectedEntries.map(entryFrom).filter(Boolean)
    : [];

  if (lockedEntries.length) return lockedEntries.sort((a, b) => a.order - b.order);

  const feedbackEntries = [
    result?.finalFeedback?.entry1,
    result?.finalFeedback?.entry2,
    result?.finalFeedback?.entry3,
  ]
    .map(entryFrom)
    .filter(Boolean);

  if (feedbackEntries.length) return feedbackEntries.sort((a, b) => a.order - b.order);

  return factsSelectedEntries(result).sort((a, b) => a.order - b.order);
}

function selectedEntries(result = {}) {
  return canonicalSelectedEntries(result);
}

function allPromotedEntries(result = {}) {
  return [...factsSelectedEntries(result), ...canonicalSelectedEntries(result)];
}

function entrySetsAgree(factsEntries = [], canonicalEntries = []) {
  if (factsEntries.length !== canonicalEntries.length) return false;

  return canonicalEntries.every((canonical, index) => {
    const facts = factsEntries[index];
    if (!facts) return false;
    const tolerance = defaultTolerance(canonical.center ?? facts.center ?? 1);
    return Math.abs(Number(canonical.center) - Number(facts.center)) <= tolerance;
  });
}

function referenceEntries(result = {}) {
  const references = Array.isArray(result?.analysisFacts?.structuralReferenceAreas)
    ? result.analysisFacts.structuralReferenceAreas.map(entryFrom).filter(Boolean)
    : [];
  return [...selectedEntries(result), ...references];
}

function areaContains(area, expected, tolerance) {
  if (!area) return false;
  const low = finiteNumber(area.zoneLow) ?? finiteNumber(area.center);
  const high = finiteNumber(area.zoneHigh) ?? finiteNumber(area.center);
  if (low === null || high === null) return false;
  return expected >= Math.min(low, high) - tolerance && expected <= Math.max(low, high) + tolerance;
}

function entryMatchesExpectation(area, expectedPrice, expectedType, zone, tolerance) {
  if (!area) return false;
  if (zone && isSupplyDemandType(expectedType)) {
    return areaMatchesExpectedZone(area, zone, tolerance);
  }
  if (expectedPrice === null) return Boolean(area);

  // Support/resistance is a level, so its authoritative anchor must match.
  // Demand/supply without configured boundaries retains legacy point behavior.
  const normalizedType = normalizeAreaType(expectedType);
  if (["support", "resistance", "converted support", "converted resistance"].includes(normalizedType)) {
    const center = finiteNumber(area.center);
    return center !== null && Math.abs(center - expectedPrice) <= tolerance;
  }
  return areaContains(area, expectedPrice, tolerance);
}

function textMentionsPrice(text, price, tolerance, expectedDigits = null) {
  const source = String(text || "");
  if (!source) return false;
  const digits = Number.isInteger(expectedDigits)
    ? expectedDigits
    : priceDigits(price);
  const candidates = source.match(/\d+(?:\.\d+)?/g) || [];
  return candidates.some((candidate) => {
    const value = Number(candidate);
    if (!Number.isFinite(value)) return false;
    const adaptiveTolerance = Math.max(tolerance, 0.5 * 10 ** -digits);
    return Math.abs(value - price) <= adaptiveTolerance;
  });
}

function duplicateItems(items = []) {
  const seen = new Set();
  const duplicates = [];
  for (const item of items) {
    const normalized = normalizeText(item);
    if (!normalized) continue;
    if (seen.has(normalized)) duplicates.push(item);
    seen.add(normalized);
  }
  return duplicates;
}

function feedbackTemplateFingerprint(value = "") {
  // Preserve instrument-specific prices, direction and structural roles.
  // Removing those facts made genuinely chart-specific feedback appear to be
  // a reused generic template. Exact rendered boilerplate is still caught.
  return normalizeText(value).replace(/\s+/g, " ").trim();
}

function feedbackItems(result = {}) {
  const strengths = Array.isArray(result?.finalFeedback?.strengths)
    ? result.finalFeedback.strengths
    : Array.isArray(result?.dashboard?.strengths)
    ? result.dashboard.strengths
    : [];
  const weaknesses = Array.isArray(result?.finalFeedback?.weaknesses)
    ? result.finalFeedback.weaknesses
    : Array.isArray(result?.dashboard?.weaknesses)
    ? result.dashboard.weaknesses
    : [];
  return [...strengths, ...weaknesses]
    .map(feedbackTemplateFingerprint)
    .filter((item) => item.length >= 30);
}

function refreshValidation(validation = {}) {
  const checks = Array.isArray(validation.checks) ? validation.checks : [];
  const failedChecks = checks.filter((check) => !check.passed);
  const criticalFailures = failedChecks.filter((check) => check.critical);
  return {
    ...validation,
    passed: criticalFailures.length === 0,
    score: checks.length
      ? Math.round(((checks.length - failedChecks.length) / checks.length) * 100)
      : 100,
    checks,
    failedChecks,
    criticalFailures,
  };
}

export function applyBatchFeedbackDiversityChecks(results = []) {
  const eligible = results
    .map((item, index) => ({ item, index, templates: feedbackItems(item?.analysis) }))
    .filter(({ item, templates }) => item?.status !== "error" && item?.analysis?.benchmarkDiagnosticOnly !== true && templates.length > 0);

  const collisions = new Map();
  for (let left = 0; left < eligible.length; left += 1) {
    for (let right = left + 1; right < eligible.length; right += 1) {
      const shared = [...new Set(eligible[left].templates)].filter((template) =>
        eligible[right].templates.includes(template)
      );
      // A couple of generic readiness reminders are acceptable when most of
      // the feedback is chart-specific. Reject a run only when repeated
      // boilerplate makes up at least half of the shorter chart's feedback.
      const shorterFeedbackCount = Math.min(
        eligible[left].templates.length,
        eligible[right].templates.length
      );
      if (shared.length < 2 || shared.length / shorterFeedbackCount < 0.5) continue;
      collisions.set(eligible[left].index, Math.max(collisions.get(eligible[left].index) || 0, shared.length));
      collisions.set(eligible[right].index, Math.max(collisions.get(eligible[right].index) || 0, shared.length));
    }
  }

  return results.map((item, index) => {
    const sharedCount = collisions.get(index) || 0;
    if (!sharedCount || !item?.validation) return item;
    const checks = Array.isArray(item.validation.checks) ? [...item.validation.checks] : [];
    checks.push({
      id: "batch_feedback_diversity",
      label: "Chart-specific strengths and weaknesses",
      passed: false,
      details: `${sharedCount} identical feedback statements were reused across different charts.`,
      critical: true,
    });
    const validation = refreshValidation({ ...item.validation, checks });
    return { ...item, status: validation.passed ? "passed" : "failed", validation };
  });
}

function addCheck(checks, id, label, passed, details, critical = true) {
  checks.push({ id, label, passed: Boolean(passed), details: details || "", critical });
}

function expectedFrameworkInventory(timeframe = "", latestVisibleDate = "") {
  const tf = String(timeframe || "").toUpperCase();
  const date = /^\d{4}-\d{2}-\d{2}$/.test(String(latestVisibleDate || ""))
    ? new Date(`${latestVisibleDate}T00:00:00.000Z`)
    : null;
  if (!date || Number.isNaN(date.getTime())) return null;

  if (["M1", "M5", "M15", "M30", "H1"].includes(tf)) {
    const weekday = date.getUTCDay();
    return {
      sourceUnit: "D1",
      expectedCount: weekday >= 1 && weekday <= 5 ? weekday : 5,
      label: "D1 candle inventory for the current trading week",
    };
  }

  if (tf === "H4") {
    const mondayWeeks = new Set();
    for (let day = 1; day <= date.getUTCDate(); day += 1) {
      const cursor = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), day));
      const weekday = cursor.getUTCDay();
      if (weekday === 0 || weekday === 6) continue;
      const monday = new Date(cursor);
      monday.setUTCDate(cursor.getUTCDate() - (weekday - 1));
      mondayWeeks.add(monday.toISOString().slice(0, 10));
    }
    return {
      sourceUnit: "W1",
      expectedCount: mondayWeeks.size,
      label: "W1 candle inventory for the current calendar month",
    };
  }

  if (tf === "D1") {
    return { sourceUnit: "MN", expectedCount: date.getUTCMonth() + 1,
      expectedDates: Array.from({ length: date.getUTCMonth() + 1 }, (_, index) =>
        `${date.getUTCFullYear()}-${String(index + 1).padStart(2, "0")}-01`),
      label: "Calendar-month inventory through cutoff; current month context-only" };
  }
  return null;
}

export function validateBenchmarkResult(result = {}, expectation = {}) {
  const checks = [];
  const toleranceOverride = finiteNumber(expectation.tolerance);
  const direction = normalizeDirection(
    result?.analysisFacts?.direction ||
      result?.regressionSnapshot?.direction ||
      result?.csaDirectionalBias?.biasCode ||
      result?.csaDirectionalBias?.bias ||
      result?.finalFeedback?.directionalBias ||
      ""
  );
  const expectedDirection = normalizeDirection(expectation.expectedDirection || "");
  const entries = selectedEntries(result);
  const factsEntries = factsSelectedEntries(result).sort((a, b) => a.order - b.order);
  const promotedEntries = allPromotedEntries(result);
  const references = referenceEntries(result);
  const feedbackText = String(result?.analysis || result?.summary || result?.finalFeedback?.analysis || "");
  const priceDiagnostics = result?.analysisFacts?.selectorDiagnostics;
  if (priceDiagnostics) {
    const unverifiedEntries = (priceDiagnostics.selectedEntries || []).filter(entry =>
      entry?.provenanceVerified === false || /unverified|estimated_period/.test(String(entry?.priceSource || "")));
    addCheck(checks, "automatic_selected_price_provenance", "Selected prices have verified provenance",
      unverifiedEntries.length === 0, unverifiedEntries.length
        ? "Unverified period estimates were selected as entries; do not save this result."
        : "No explicitly unverified period estimate was selected.");
    if (priceDiagnostics.transparencyAudit?.fibonacciAudit?.verified === false) {
      addCheck(checks, "verified_fibonacci_frame", "Fixed-period frame has verified price authority", false,
        "The frame is unverified. A saved expected result cannot override missing price authority.");
    }
  }

  if (expectation.automaticMode === true) {
    const detectedInstrument = String(
      result?.chartDetection?.detectedInstrument || result?.detectedPair || ""
    ).trim();
    const detectedTimeframe = String(
      result?.chartDetection?.detectedTimeframe || result?.detectedTimeframe || ""
    ).trim();
    const selectorDiagnostics = result?.analysisFacts?.selectorDiagnostics;
    const frameworkInventory = Array.isArray(selectorDiagnostics?.periodInventory)
      ? selectorDiagnostics.periodInventory
      : Array.isArray(selectorDiagnostics?.periodDayInventory)
      ? selectorDiagnostics.periodDayInventory
      : [];
    const latestVisibleDate = String(
      result?.chartDetection?.latestVisibleDate || result?.detectedLatestVisibleDate || ""
    );
    const inventoryRequirement = expectedFrameworkInventory(detectedTimeframe, latestVisibleDate);
    const inventoryPeriodsValid = frameworkInventory.every((period) => {
      const high = finiteNumber(period?.high);
      const low = finiteNumber(period?.low);
      return high !== null && low !== null && high > low;
    });
    const frameworkInventoryComplete = !inventoryRequirement || (
      frameworkInventory.length >= inventoryRequirement.expectedCount && inventoryPeriodsValid &&
      (!inventoryRequirement.expectedDates || (
        frameworkInventory.length === inventoryRequirement.expectedDates.length &&
        inventoryRequirement.expectedDates.every((date, index) => frameworkInventory[index]?.date === date)))
    );
    const fibCandidates = Array.isArray(selectorDiagnostics?.fibCandidates)
      ? selectorDiagnostics.fibCandidates
      : [];
    const fallbackSelectedEntries = Array.isArray(selectorDiagnostics?.selectedEntries)
      ? selectorDiagnostics.selectedEntries
      : [];
    const fallbackSelectorCompleted =
      String(selectorDiagnostics?.fallbackSource || "").startsWith("uploaded_chart_only") &&
      (
        Array.isArray(selectorDiagnostics?.structuralCandidates) ||
        fallbackSelectedEntries.length > 0
      );
    const fallbackSwingHigh = finiteNumber(selectorDiagnostics?.fibonacci?.swingHigh);
    const fallbackSwingLow = finiteNumber(selectorDiagnostics?.fibonacci?.swingLow);
    const fallbackRange = fallbackSwingHigh !== null && fallbackSwingLow !== null && fallbackSwingHigh > fallbackSwingLow
      ? fallbackSwingHigh - fallbackSwingLow
      : null;
    const requiresCurrentPeriodFrame = ["M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1", "MN"].includes(
      String(detectedTimeframe || "").toUpperCase()
    );
    const currentPeriodFrameAvailable =
      !requiresCurrentPeriodFrame ||
      (
        fallbackRange !== null &&
        !String(selectorDiagnostics?.fibonacci?.source || "").endsWith("_required")
      );
    const recognizedTypes = new Set([
      "support", "resistance", "converted support", "converted resistance",
      "demand", "supply",
    ]);
    const everyEntryIsStructured = entries.every((entry) =>
      recognizedTypes.has(normalizeAreaType(entry.areaType))
    );
    const formatFibLabel = (match = {}) => {
      const ratio = finiteNumber(match?.ratio);
      const price = finiteNumber(match?.price);
      const suffix = price === null ? "" : ` @ ${String(price)}`;
      const explicitLabel = String(match?.label || "").trim();
      if (explicitLabel.toLowerCase().startsWith("between ")) {
        return `${explicitLabel}${suffix}`;
      }
      if (ratio !== null) {
        return `${ratio === 0.5 ? "50%" : `${(ratio * 100).toFixed(1)}%`}${suffix}`;
      }
      const label = String(match?.label || "").trim();
      return label ? `${label.replace(/\.0(?=%)/, "")}${suffix}` : null;
    };
    const fibEvidenceForEntry = (entry) => {
      const entryPrice = finiteNumber(entry.center);
      if (entryPrice === null) return [];
      const displayedDecimals = String(entry.levelText || "").split(".")[1]?.length;
      const displayRoundingTolerance = Number.isInteger(displayedDecimals)
        ? 0.5 * (10 ** -displayedDecimals) + Number.EPSILON
        : 0;
      const tolerance = Math.max(defaultTolerance(entryPrice), displayRoundingTolerance);
      const matchedEvaluatedCandidate = fibCandidates.some((candidate) => {
        if (candidate?.passed !== true) return false;
        const candidatePrice =
          finiteNumber(candidate.resolvedEntryPrice) ??
          finiteNumber(candidate.chartReconciledPrice) ??
          finiteNumber(candidate.frameworkPrice);
        return candidatePrice !== null &&
          Math.abs(candidatePrice - entryPrice) <= tolerance;
      });

      const candidateEvidence = fibCandidates
        .filter((candidate) => {
          if (candidate?.passed !== true) return false;
          const candidatePrice =
            finiteNumber(candidate.resolvedEntryPrice) ??
            finiteNumber(candidate.chartReconciledPrice) ??
            finiteNumber(candidate.frameworkPrice);
          return candidatePrice !== null && Math.abs(candidatePrice - entryPrice) <= tolerance;
        })
        .flatMap((candidate) => [
          ...(Array.isArray(candidate?.matchedLevels) ? candidate.matchedLevels : []),
          ...(Array.isArray(candidate?.evaluatedFibLevels)
            ? candidate.evaluatedFibLevels.filter((match) => match?.passed === true)
            : []),
        ])
        .map(formatFibLabel)
        .filter(Boolean);

      if (matchedEvaluatedCandidate) {
        return [...new Set(candidateEvidence)];
      }

      // The chart-native fallback already performs the same ordered
      // structure -> hidden-Fibonacci gate before it promotes an entry. Its
      // compact diagnostics contain the selected entries themselves rather
      // than the full structuralCandidates/fibCandidates audit arrays. Match
      // those entries by price and require an explicit 38.2/50/61.8 record;
      // never infer confluence from a selected price alone.
      const fallbackEvidence = fallbackSelectedEntries.flatMap((candidate) => {
        const candidatePrice =
          finiteNumber(candidate.authoritativeCenter) ??
          finiteNumber(candidate.resolvedEntryPrice);
        const matches = Array.isArray(candidate?.fibonacciMatches)
          ? candidate.fibonacciMatches
          : [];
        const approvedMatches = matches.filter((match) => {
          const ratio = finiteNumber(match?.ratio);
          const approvedRatio = ratio !== null
            ? [0.382, 0.5, 0.618].find((approved) => Math.abs(ratio - approved) <= 0.002)
            : null;
          if (!approvedRatio || fallbackRange === null || candidatePrice === null) return false;
          const fib382 = direction === "bearish"
            ? fallbackSwingLow + fallbackRange * 0.382
            : fallbackSwingHigh - fallbackRange * 0.382;
          const fib618 = direction === "bearish"
            ? fallbackSwingLow + fallbackRange * 0.618
            : fallbackSwingHigh - fallbackRange * 0.618;
          const bandLow = Math.min(fib382, fib618);
          const bandHigh = Math.max(fib382, fib618);
          const boundaryAllowance = Math.max(
            defaultTolerance(candidatePrice),
            Math.min(
              finiteNumber(candidate?.fibonacciTolerance) ?? 0,
              fallbackRange * 0.01
            )
          );
          return candidatePrice >= bandLow - boundaryAllowance &&
            candidatePrice <= bandHigh + boundaryAllowance;
        });
        return candidatePrice !== null &&
          Math.abs(candidatePrice - entryPrice) <= tolerance
          ? approvedMatches.map(formatFibLabel).filter(Boolean)
          : [];
      });
      return [...new Set(fallbackEvidence)];
    };
    const entryFibEvidence = entries.map((entry) => fibEvidenceForEntry(entry));
    const everyEntryHasFibConfluence = entryFibEvidence.every((evidence) => evidence.length > 0);
    const structuralBias = normalizeDirection(
      result?.csaDirectionalBias?.biasCode || result?.csaDirectionalBias?.bias || ""
    );
    const structuralBiasDeclared = Boolean(result?.csaDirectionalBias);
    const structuralBiasAvailable = ["bullish", "bearish", "range"].includes(structuralBias);

    addCheck(
      checks,
      "automatic_chart_context",
      "Instrument and timeframe detected",
      Boolean(detectedInstrument && detectedTimeframe),
      `Detected ${detectedInstrument || "no instrument"} on ${detectedTimeframe || "no timeframe"}.`
    );
    addCheck(
      checks,
      "automatic_direction",
      "Directional bias resolved",
      direction !== "unknown",
      `Resolved direction: ${direction}.`
    );
    addCheck(
      checks,
      "automatic_structural_bias_consistency",
      "Headline bias agrees with verified period structure",
      !structuralBiasDeclared || (structuralBiasAvailable && direction === structuralBias),
      !structuralBiasDeclared
        ? "No separate structural-bias field was supplied by this legacy fixture."
        : !structuralBiasAvailable
        ? "Verified period structure is unavailable; do not present a visual range estimate as an authoritative bias."
        : direction === structuralBias
        ? `Structural bias: ${structuralBias}.`
        : `Headline bias ${direction} conflicts with verified period bias ${structuralBias}.`
    );
    addCheck(
      checks,
      "automatic_framework_period_inventory",
      "Timeframe-specific D1/W1 candle highs and lows were inventoried",
      frameworkInventoryComplete,
      inventoryRequirement
        ? `${inventoryRequirement.label}: expected ${inventoryRequirement.expectedCount}, returned ${frameworkInventory.length}.`
        : "No dated H1/H4 inventory requirement could be calculated for this result."
    );
    addCheck(
      checks,
      "automatic_fibonacci_period_frame",
      "Current-period Fibonacci high and low were read",
      currentPeriodFrameAvailable && selectorDiagnostics?.transparencyAudit?.fibonacciAudit?.verified !== false,
      currentPeriodFrameAvailable
        ? `Frame: high ${fallbackSwingHigh}, low ${fallbackSwingLow}.`
        : "No entry can be accepted until the required current-period high and low are both read from the chart."
    );
    const selectorVersionParts = String(selectorDiagnostics?.selectorVersion || "0")
      .split(".")
      .map((part) => Number(part) || 0);
    const transparentAuditRequired =
      selectorVersionParts[0] > 4 ||
      (selectorVersionParts[0] === 4 && selectorVersionParts[1] >= 28);
    if (transparentAuditRequired) {
      const transparencyAudit = selectorDiagnostics?.transparencyAudit || {};
      const transparentDiagnosticsComplete =
        Array.isArray(transparencyAudit.periodStructureAudit) &&
        transparencyAudit.periodStructureAudit.length > 0 &&
        finiteNumber(transparencyAudit?.fibonacciAudit?.swingHigh) !== null &&
        finiteNumber(transparencyAudit?.fibonacciAudit?.swingLow) !== null &&
        Array.isArray(transparencyAudit.candidateEvaluationAudit) &&
        Array.isArray(transparencyAudit.entryDecisionAudit) &&
        transparencyAudit.entryDecisionAudit.length === 3 &&
        Array.isArray(transparencyAudit.provenanceConflicts);
      addCheck(
        checks,
        "automatic_transparent_selector_audit",
        "Period, structure, Fibonacci, entry and provenance diagnostics returned",
        transparentDiagnosticsComplete,
        transparentDiagnosticsComplete
          ? `${transparencyAudit.periodStructureAudit.length} period(s) and ${transparencyAudit.candidateEvaluationAudit.length} candidate(s) are fully auditable.`
          : "Selector 4.28+ must return period structure, Fib range, candidate decisions, Entry 1-3 decisions and provenance conflicts."
      );
      if (String(transparencyAudit?.auditVersion || "").startsWith("1.1")) {
        const inventoryConflicts = (Array.isArray(transparencyAudit.provenanceConflicts)
          ? transparencyAudit.provenanceConflicts
          : []).filter((conflict) =>
            conflict?.requiresReview === true || (conflict?.requiresReview !== false && (
              Number.isFinite(Number(conflict?.chartPrice)) ||
              Number.isFinite(Number(conflict?.chartCount))
            ))
          );
        const chartRasterAuthorityVerified =
          transparencyAudit.inventoryAuthority?.chartOnlyInventoryVerified === true;
        const authorityMissing =
          Boolean(transparencyAudit.inventoryAuthority?.providerFailure) &&
          !chartRasterAuthorityVerified;
        addCheck(
          checks,
          "automatic_period_price_authority",
          "Period price authority is available without unresolved conflicts",
          !authorityMissing && inventoryConflicts.length === 0,
          inventoryConflicts.length
            ? `${inventoryConflicts.length} period high/low conflict(s) were exposed. Review the chart values before saving this result.`
            : authorityMissing ? "Neither provider nor calibrated chart-raster price authority is available."
            : chartRasterAuthorityVerified ? "Calibrated chart-raster prices are verified against the visible final-candle header; broker-feed equivalence is not claimed."
            : "No unresolved chart-versus-market period high/low conflict was found."
        );
      }
    }
    addCheck(
      checks,
      "ordered_selector",
      "S/R → S/D → Fibonacci sequence completed",
      Boolean(
        selectorDiagnostics &&
        (
          (
            Array.isArray(selectorDiagnostics.structuralCandidates) &&
            Array.isArray(selectorDiagnostics.fibCandidates)
          ) ||
          fallbackSelectorCompleted
        )
      ),
      selectorDiagnostics
        ? `Selector ${selectorDiagnostics.selectorVersion || "unknown"} evaluated structure before Fibonacci filtering.`
        : "Ordered selector diagnostics were not returned."
    );
    addCheck(
      checks,
      "automatic_structural_roles",
      "Selected entries use valid structural roles",
      everyEntryIsStructured,
      everyEntryIsStructured
        ? `${entries.length} selected entr${entries.length === 1 ? "y uses" : "ies use"} support/resistance or supply/demand structure.`
        : "At least one selected entry has an unsupported structural role."
    );
    addCheck(
      checks,
      "automatic_fibonacci_confluence",
      "Selected entries pass hidden Fibonacci confluence",
      everyEntryHasFibConfluence,
      everyEntryHasFibConfluence
        ? entries.map((entry, index) =>
            `Entry ${index + 1} (${entry.levelText || entry.center}): ${entryFibEvidence[index].join(" / ")}`
          ).join("; ")
        : "At least one selected entry was not matched to a passed hidden Fibonacci candidate."
    );
  }

  if (expectation.noEntryExpected === true) {
    addCheck(
      checks,
      "no_entry_expected",
      "No valid entry returned",
      factsEntries.length === 0 && entries.length === 0,
      `Expected no selected entries; structured facts returned ${factsEntries.length} and customer-facing output returned ${entries.length}.`
    );
  }

  if (expectedDirection !== "unknown") {
    addCheck(
      checks,
      "direction",
      "Directional bias",
      direction === expectedDirection,
      `Expected ${expectedDirection}; received ${direction}.`
    );
  }

  addCheck(
    checks,
    "maximum_three_entries",
    "Maximum three selected entries",
    factsEntries.length <= 3 && entries.length <= 3,
    `Structured facts returned ${factsEntries.length}; customer-facing output returned ${entries.length}.`
  );

  const expectedEntryCount = finiteNumber(expectation.expectedEntryCount);
  if (expectedEntryCount !== null) {
    addCheck(
      checks,
      "expected_entry_count",
      "Verified number of entries",
      factsEntries.length === expectedEntryCount && entries.length === expectedEntryCount,
      `Expected exactly ${expectedEntryCount}; structured facts returned ${factsEntries.length} and customer-facing output returned ${entries.length}.`
    );
  }

  addCheck(
    checks,
    "canonical_entry_consistency",
    "Internal and customer-facing entries agree",
    entrySetsAgree(factsEntries, entries),
    `Structured facts contain ${factsEntries.length} entr${factsEntries.length === 1 ? "y" : "ies"}; canonical feedback contains ${entries.length}.`
  );

  const expectedEntry1 = finiteNumber(expectation.expectedEntry1);
  const expectedEntry1Type = normalizeAreaType(expectation.expectedEntry1Type || "");
  const entry1Zone = expectedEntryZone(expectation, 1);
  if (expectedEntry1 !== null || entry1Zone) {
    const tolerance = toleranceOverride ?? defaultTolerance(expectedEntry1);
    addCheck(
      checks,
      "entry_1",
      "Entry 1",
      entryMatchesExpectation(entries[0], expectedEntry1, expectedEntry1Type, entry1Zone, tolerance),
      entries[0]
        ? entry1Zone
          ? `Expected ${expectedEntry1Type} zone ${formatExpectedZone(entry1Zone)}; received ${entries[0].levelText || entries[0].center} (${entries[0].zoneLow}–${entries[0].zoneHigh}).`
          : `Expected ${expectedEntry1}; received ${entries[0].levelText || entries[0].center}.`
        : `Expected ${entry1Zone ? `${expectedEntry1Type} zone ${formatExpectedZone(entry1Zone)}` : expectedEntry1}; no Entry 1 was returned.`
    );
  }

  if (expectedEntry1Type !== "unknown") {
    const actualEntry1 = factsEntries[0] || entries[0] || null;
    addCheck(
      checks,
      "entry_1_type",
      "Entry 1 structural role",
      Boolean(actualEntry1) && areaTypeMatches(actualEntry1.areaType, expectedEntry1Type),
      actualEntry1
        ? `Expected ${expectedEntry1Type}; received ${normalizeAreaType(actualEntry1.areaType)}.`
        : `Expected ${expectedEntry1Type}; no Entry 1 was returned.`
    );
  }

  const expectedEntry2 = finiteNumber(expectation.expectedEntry2);
  const expectedEntry2Type = normalizeAreaType(expectation.expectedEntry2Type || "");
  const entry2Zone = expectedEntryZone(expectation, 2);
  const entry2Required = expectation.entry2Required === true || expectedEntry2 !== null || Boolean(entry2Zone);
  if (entry2Required) {
    const tolerance = toleranceOverride ?? defaultTolerance(expectedEntry2 ?? entries[1]?.center ?? 1);
    const passed = entryMatchesExpectation(
      entries[1],
      expectedEntry2,
      expectedEntry2Type,
      entry2Zone,
      tolerance
    );
    addCheck(
      checks,
      "entry_2",
      "Entry 2",
      passed,
      entries[1]
        ? entry2Zone
          ? `Expected ${expectedEntry2Type} zone ${formatExpectedZone(entry2Zone)}; received ${entries[1].levelText || entries[1].center} (${entries[1].zoneLow}–${entries[1].zoneHigh}).`
          : `Expected ${expectedEntry2 ?? "a second entry"}; received ${entries[1].levelText || entries[1].center}.`
        : "A valid Entry 2 was required but none was returned."
    );
  }

  if (expectedEntry2Type !== "unknown") {
    const actualEntry2 = factsEntries[1] || entries[1] || null;
    addCheck(
      checks,
      "entry_2_type",
      "Entry 2 structural role",
      Boolean(actualEntry2) && areaTypeMatches(actualEntry2.areaType, expectedEntry2Type),
      actualEntry2
        ? `Expected ${expectedEntry2Type}; received ${normalizeAreaType(actualEntry2.areaType)}.`
        : `Expected ${expectedEntry2Type}; no Entry 2 was returned.`
    );
  }

  const expectedEntry3 = finiteNumber(expectation.expectedEntry3);
  const expectedEntry3Type = normalizeAreaType(expectation.expectedEntry3Type || "");
  const entry3Zone = expectedEntryZone(expectation, 3);
  const entry3Required = expectation.entry3Required === true || expectedEntry3 !== null || Boolean(entry3Zone);
  if (entry3Required) {
    const tolerance = toleranceOverride ?? defaultTolerance(expectedEntry3 ?? entries[2]?.center ?? 1);
    addCheck(
      checks,
      "entry_3",
      "Entry 3",
      entryMatchesExpectation(entries[2], expectedEntry3, expectedEntry3Type, entry3Zone, tolerance),
      entries[2]
        ? `Expected ${expectedEntry3 ?? formatExpectedZone(entry3Zone)}; received ${entries[2].levelText || entries[2].center}.`
        : "A valid Entry 3 was required but none was returned."
    );
  }

  if (expectedEntry3Type !== "unknown") {
    const actualEntry3 = factsEntries[2] || entries[2] || null;
    addCheck(
      checks,
      "entry_3_type",
      "Entry 3 structural role",
      Boolean(actualEntry3) && areaTypeMatches(actualEntry3.areaType, expectedEntry3Type),
      actualEntry3
        ? `Expected ${expectedEntry3Type}; received ${normalizeAreaType(actualEntry3.areaType)}.`
        : `Expected ${expectedEntry3Type}; no Entry 3 was returned.`
    );
  }

  const configuredEntryZones = [
    { entry: entries[0], zone: entry1Zone, type: expectedEntry1Type },
    { entry: entries[1], zone: entry2Zone, type: expectedEntry2Type },
    { entry: entries[2], zone: entry3Zone, type: expectedEntry3Type },
  ].filter((item) => item.zone && isSupplyDemandType(item.type));

  for (const required of parsePriceExpectations(expectation.requiredLevels)) {
    const requiredPrice = required.value;
    const tolerance =
      finiteNumber(expectation.levelTolerance) ??
      toleranceOverride ??
      exactLevelTolerance(requiredPrice, required.digits);
    const matchingZoneExpectation = configuredEntryZones.find((item) =>
      priceInsideZone(requiredPrice, item.zone, tolerance)
    );
    const present = matchingZoneExpectation
      ? areaMatchesExpectedZone(
          matchingZoneExpectation.entry,
          matchingZoneExpectation.zone,
          tolerance
        ) || textMentionsZone(feedbackText, matchingZoneExpectation.zone, tolerance)
      : references.some((area) => Math.abs(Number(area.center) - requiredPrice) <= tolerance) ||
        textMentionsPrice(feedbackText, requiredPrice, tolerance, required.digits);
    addCheck(
      checks,
      `required_level_${requiredPrice}`,
      `Required level ${requiredPrice}`,
      present,
      present
        ? matchingZoneExpectation
          ? `The configured ${matchingZoneExpectation.type} zone is represented by the selected entry or feedback.`
          : "The exact level is present in the structured facts or feedback."
        : matchingZoneExpectation
        ? `The required ${matchingZoneExpectation.type} zone ${formatExpectedZone(matchingZoneExpectation.zone)} is missing.`
        : "The exact required level is missing; broad zone containment does not count."
    );
  }

  for (const required of parsePriceExpectations(expectation.requiredFeedbackLevels)) {
    const requiredPrice = required.value;
    const tolerance =
      finiteNumber(expectation.levelTolerance) ??
      toleranceOverride ??
      exactLevelTolerance(requiredPrice, required.digits);
    const matchingZoneExpectation = configuredEntryZones.find((item) =>
      priceInsideZone(requiredPrice, item.zone, tolerance)
    );
    const present = matchingZoneExpectation
      ? textMentionsZone(feedbackText, matchingZoneExpectation.zone, tolerance)
      : textMentionsPrice(feedbackText, requiredPrice, tolerance, required.digits);
    addCheck(
      checks,
      `required_feedback_level_${requiredPrice}`,
      `Feedback must mention ${requiredPrice}`,
      present,
      present
        ? matchingZoneExpectation
          ? `Customer-facing feedback mentions a price inside the configured ${matchingZoneExpectation.type} zone.`
          : "The exact level is present in customer-facing feedback."
        : matchingZoneExpectation
        ? `Customer-facing feedback does not mention the configured ${matchingZoneExpectation.type} zone ${formatExpectedZone(matchingZoneExpectation.zone)}.`
        : "The required level is absent from customer-facing feedback."
    );
  }

  for (const requiredTerm of parseTextList(expectation.requiredFeedbackTerms)) {
    const present = feedbackMentionsTerm(feedbackText, requiredTerm);
    addCheck(
      checks,
      `required_feedback_term_${normalizeText(requiredTerm).replace(/\s+/g, "_")}`,
      `Feedback must include “${requiredTerm}”`,
      present,
      present
        ? "The required wording is present in customer-facing feedback."
        : `Customer-facing feedback does not include “${requiredTerm}”.`
    );
  }

  for (const forbiddenPrice of parseList(expectation.forbiddenEntries)) {
    const tolerance = toleranceOverride ?? defaultTolerance(forbiddenPrice);
    const promoted = promotedEntries.some((area) => areaContains(area, forbiddenPrice, tolerance));
    addCheck(
      checks,
      `forbidden_entry_${forbiddenPrice}`,
      `Forbidden entry ${forbiddenPrice}`,
      !promoted,
      promoted
        ? "This structural reference was incorrectly promoted as an entry."
        : "The price was not promoted as Entry 1 or Entry 2."
    );
  }

  const strengths = Array.isArray(result?.finalFeedback?.strengths)
    ? result.finalFeedback.strengths
    : Array.isArray(result?.dashboard?.strengths)
    ? result.dashboard.strengths
    : [];
  const weaknesses = Array.isArray(result?.finalFeedback?.weaknesses)
    ? result.finalFeedback.weaknesses
    : Array.isArray(result?.dashboard?.weaknesses)
    ? result.dashboard.weaknesses
    : [];

  addCheck(checks, "strength_limit", "Maximum four strengths", strengths.length <= 4, `${strengths.length} returned.`, false);
  addCheck(checks, "weakness_limit", "Maximum four weaknesses", weaknesses.length <= 4, `${weaknesses.length} returned.`, false);
  addCheck(checks, "duplicate_strengths", "No duplicate strengths", duplicateItems(strengths).length === 0, "Exact normalized duplicates are not allowed.", false);
  addCheck(checks, "duplicate_weaknesses", "No duplicate weaknesses", duplicateItems(weaknesses).length === 0, "Exact normalized duplicates are not allowed.", false);
  addCheck(checks, "hidden_fibonacci", "Fibonacci remains internal", !FIB_WORDS.test(feedbackText), "Customer-facing feedback must not mention Fibonacci.");
  addCheck(checks, "neutral_level_labels", "No day-of-week labels", !DAY_WORDS.test(feedbackText), "Use neutral support/resistance wording.", false);

  const failedChecks = checks.filter((check) => !check.passed);
  const criticalFailures = failedChecks.filter((check) => check.critical);
  const score = checks.length ? Math.round((checks.length - failedChecks.length) / checks.length * 100) : 100;

  return {
    passed: criticalFailures.length === 0,
    score,
    direction,
    selectedEntries: entries,
    checks,
    failedChecks,
    criticalFailures,
    versions: {
      benchmarkValidatorVersion: BENCHMARK_VALIDATOR_VERSION,
      buildId: result?.buildId || null,
      feedbackEngineVersion: result?.feedbackEngineVersion || null,
      selectorVersion: result?.selectorVersion || null,
      regressionEngineVersion: result?.regressionSnapshot?.engineVersion || null,
    },
  };
}

export const benchmarkValidatorInternals = {
  normalizeDirection,
  parseList,
  parsePriceExpectations,
  parseTextList,
  normalizeAreaType,
  areaTypeMatches,
  feedbackMentionsTerm,
  selectedEntries,
  factsSelectedEntries,
  canonicalSelectedEntries,
  referenceEntries,
  areaContains,
  areaMatchesExpectedZone,
  expectedEntryZone,
  entryMatchesExpectation,
  normalizeZoneBounds,
  textMentionsZone,
  defaultTolerance,
  exactLevelTolerance,
  feedbackTemplateFingerprint,
};
